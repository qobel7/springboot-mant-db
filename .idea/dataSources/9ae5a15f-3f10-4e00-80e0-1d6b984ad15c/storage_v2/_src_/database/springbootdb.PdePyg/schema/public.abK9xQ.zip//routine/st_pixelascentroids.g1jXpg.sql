create function st_pixelascentroids(rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, OUT geom geometry, OUT val double precision, OUT x integer, OUT y integer) returns SETOF record
  immutable
  strict
  parallel safe
  language sql
as
$$
SELECT public.ST_Centroid(geom), val, x, y FROM public._ST_pixelaspolygons($1, $2, NULL, NULL, $3)
$$;

comment on function st_pixelascentroids(raster, integer, boolean, out geometry, out double precision, out integer, out integer) is 'args: rast, band=1, exclude_nodata_value=TRUE - Returns the centroid (point geometry) for each pixel of a raster band along with the value, the X and the Y raster coordinates of each pixel. The point geometry is the centroid of the area represented by a pixel.';

alter function st_pixelascentroids(raster, integer, boolean, out geometry, out double precision, out integer, out integer) owner to postgres;

