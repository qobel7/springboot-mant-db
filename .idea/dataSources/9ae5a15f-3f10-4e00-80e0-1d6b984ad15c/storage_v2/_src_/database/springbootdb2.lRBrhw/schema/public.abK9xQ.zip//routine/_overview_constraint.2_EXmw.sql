create function "_overview_constraint"(ov raster, factor integer, refschema name, reftable name, refcolumn name) returns boolean
  stable
  language sql
as
$$
SELECT COALESCE((SELECT TRUE FROM public.raster_columns WHERE r_table_catalog = current_database() AND r_table_schema = $3 AND r_table_name = $4 AND r_raster_column = $5), FALSE)
$$;

alter function "_overview_constraint"(raster, integer, name, name, name) owner to postgres;

