create function st_approxquantile(rastertable text, rastercolumn text, quantile double precision) returns double precision
  stable
  language sql
as
$$
SELECT ( public._ST_quantile($1, $2, 1, TRUE, 0.1, ARRAY[$3]::double precision[])).value
$$;

alter function st_approxquantile(text, text, double precision) owner to postgres;

