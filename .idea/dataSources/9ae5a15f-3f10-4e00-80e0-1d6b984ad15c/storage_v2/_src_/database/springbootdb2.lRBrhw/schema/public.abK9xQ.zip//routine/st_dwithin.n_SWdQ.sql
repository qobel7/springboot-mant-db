create function st_dwithin(rast1 raster, nband1 integer, rast2 raster, nband2 integer, distance double precision) returns boolean
  immutable
  parallel safe
  cost 1000
  language sql
as
$$
SELECT $1::geometry OPERATOR(public.&&) ST_Expand(ST_ConvexHull($3), $5) AND $3::geometry OPERATOR(public.&&) ST_Expand(ST_ConvexHull($1), $5) AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN public._ST_dwithin(st_convexhull($1), st_convexhull($3), $5) ELSE public._ST_dwithin($1, $2, $3, $4, $5) END
$$;

comment on function st_dwithin(raster, integer, raster, integer, double precision) is 'args: rastA, nbandA, rastB, nbandB, distance_of_srid - Return true if rasters rastA and rastB are within the specified distance of each other.';

alter function st_dwithin(raster, integer, raster, integer, double precision) owner to postgres;

