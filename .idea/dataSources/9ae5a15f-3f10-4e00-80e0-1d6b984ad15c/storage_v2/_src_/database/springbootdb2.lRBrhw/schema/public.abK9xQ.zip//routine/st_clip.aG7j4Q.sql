create function st_clip(rast raster, nband integer, geom geometry, crop boolean) returns raster
  immutable
  parallel safe
  language sql
as
$$
SELECT public.ST_Clip($1, ARRAY[$2]::integer[], $3, null::double precision[], $4)
$$;

alter function st_clip(raster, integer, geometry, boolean) owner to postgres;

