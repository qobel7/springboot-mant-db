create function st_intersects(rast raster, nband integer, geom geometry) returns boolean
  immutable
  parallel safe
  cost 1000
  language sql
as
$$
SELECT $1::geometry OPERATOR(public.&&) $3 AND public._st_intersects($3, $1, $2)
$$;

comment on function st_intersects(raster, integer, geometry) is 'args: rast, nband, geommin - Return true if raster rastA spatially intersects raster rastB.';

alter function st_intersects(raster, integer, geometry) owner to postgres;

