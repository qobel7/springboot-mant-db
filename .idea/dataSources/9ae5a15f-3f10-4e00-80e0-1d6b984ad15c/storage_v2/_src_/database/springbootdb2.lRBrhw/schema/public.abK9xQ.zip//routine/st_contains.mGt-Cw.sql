create function st_contains(rast1 raster, rast2 raster) returns boolean
  immutable
  parallel safe
  cost 1000
  language sql
as
$$
SELECT public.st_contains($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_contains(raster, raster) is 'args: rastA, rastB - Return true if no points of raster rastB lie in the exterior of raster rastA and at least one point of the interior of rastB lies in the interior of rastA.';

alter function st_contains(raster, raster) owner to postgres;

