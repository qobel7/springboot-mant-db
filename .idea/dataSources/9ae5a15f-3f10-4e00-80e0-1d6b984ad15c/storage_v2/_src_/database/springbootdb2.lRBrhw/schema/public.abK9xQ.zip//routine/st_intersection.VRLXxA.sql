create function st_intersection(rast1 raster, band1 integer, rast2 raster, band2 integer, nodataval double precision) returns raster
  immutable
  parallel safe
  language sql
as
$$
SELECT st_intersection($1, $2, $3, $4, 'BOTH', ARRAY[$5, $5])
$$;

alter function st_intersection(raster, integer, raster, integer, double precision) owner to postgres;

