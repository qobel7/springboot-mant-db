create function st_histogram(rastertable text, rastercolumn text, nband integer, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
  stable
  language sql
as
$$
SELECT public._ST_histogram($1, $2, $3, TRUE, 1, $4, $5, $6)
$$;

comment on function st_histogram(text, text, integer, integer, double precision[], boolean, out double precision, out double precision, out bigint, out double precision) is 'args: rastertable, rastercolumn, nband=1, bins, width=NULL, right=false - Returns a set of record summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(text, text, integer, integer, double precision[], boolean, out double precision, out double precision, out bigint, out double precision) owner to postgres;

